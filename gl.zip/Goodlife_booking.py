#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 18:19:14 2020

@author: jayrajparmar
"""
import selenium
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import datetime
import time


#def lambda(event=None, context=None):
def goodlife_booking(email_id, password, class_time):
    #driver = webdriver.Chrome('/Users/jayrajparmar/Downloads/chromedriver')
    driver = webdriver.Chrome('/Users/jayrajparmar/Downloads/chromedriver')
    driver.get('https://www.goodlifefitness.com/members/login?redirectpath=%2fmembers%2f')
    email = driver.find_element_by_name('Email/Member #').send_keys(str(email_id))
    pss = driver.find_element_by_name('Password').send_keys(str(password))
    login = driver.find_element_by_id('btn-login').click()
    time.sleep(10)
    driver.find_element_by_xpath("//a[@href='/members/bookings/workout']").click()
    #WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//a[@href='/members/bookings/workout']")))
    time.sleep(10)
    driver.find_element_by_xpath("//div[@class='date-tile active']").click()
    lis = [1,2,3,4,5]
    date = (datetime.datetime.today() + datetime.timedelta(days = 4)).strftime('%Y-%m-%d')
    if (datetime.datetime.today() + datetime.timedelta(days = 4)).isoweekday() in lis:
        driver.find_element_by_xpath("//div[@class='date-tile' and @data-date ='"+ str(date) +"']").click()
        time.sleep(5)
        driver.find_element_by_xpath("//button[@class='cmp-button book-workout-button' and @data-display='"+ str(class_time) +"']").click()
    #WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, "//button[@id='codeOfConductAgree' and @class='btn btn-primary']")))
    time.sleep(10)
    driver.find_element_by_xpath("//button[@id='codeOfConductAgree' and @class='btn btn-primary']").click()
    driver.maximize_window()
    html = driver.find_element_by_tag_name('html')
    html.send_keys(Keys.END)    
    element = driver.find_element_by_xpath("//button[@id='confirmBookingButton' and @class='btn btn-primary']").click()
    close_buttons = WebDriverWait(driver, 1).until(EC.presence_of_all_elements_located((By.XPATH, "//button[@class ='btn btn-primary'and @data-dismiss = 'modal' and @type = 'button']")))
    time.sleep(5)
    close_buttons[1].click()
    logout = driver.find_element_by_xpath("//a[@href='/logout']").click()
    driver.close() 
    pass
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('booking was confirmed')
    # }


goodlife_booking('jayrajparmar009@gmail.com', 'Jayraj_123', '6:00 AM - 7:00 AM')
    
    

chrome_options = webdriver.ChromeOptions()
driver = webdriver.Chrome(chrome_options=chrome_options)









